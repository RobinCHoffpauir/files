---
id: resume-sample
title: Resume Sample
---

import YangshunResumeURL from '@site/static/img/yangshun-resume.png';

Here's a sample resume (mine). I like using Google Docs as the portability is great and also comes with version control. Feel free to clone my resume and use it as a starting point for your own.

Here's a [Google Doc template](https://docs.google.com/document/d/1DQ5SKNrm1hb1BRS40ejovLxhyEKXiuTGsDEXIiZSW0o/edit?usp=sharing) of my resume if you're interested.

<div class="text--center">
    <figure>
        <img alt="Yangshun's Resume 2021" class="shadow--md" src={YangshunResumeURL} />
        <figcaption>Yangshun's Resume 2021</figcaption>
    </figure>
</div>
