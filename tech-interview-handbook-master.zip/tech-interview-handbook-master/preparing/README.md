# Preparing

The contents have been moved to the [website](https://techinterviewhandbook.org/coding-round-overview).

<!-- TODO: Remove in future -->
